const Logo = () => {
  return <h1 className="logo">Lights Out</h1>;
};

export default Logo;
